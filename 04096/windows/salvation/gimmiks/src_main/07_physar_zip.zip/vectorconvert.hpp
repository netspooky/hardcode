// BezierKurven flach machen in inkscape/effecte klappt aber anscheinend nich be gro�en bildern
#ifdef CONVERTSTEP
#define blowUpFactorX 1.f
#define blowUpFactorY 1.f

#include <stdio.h>

unsigned char Buffer[1024*1024*400];

int lastcoordx=0;
int lastcoordy=0;
int lastWasC0orL1orM2=0;

void  OutputCoords(FILE *outf,float coordx,float coordy)
{
  int x = efloor(coordx);
  int y = efloor(coordy);
  //x &= ~1;
  //y &= ~1;
  x-=lastcoordx;
  y-=lastcoordy;
  lastcoordx += x;
  lastcoordy += y;
/*if (x>0x7fff) x = 0x7fff;
  if (x<-0x7fff) x = -0x7fff;
  if (y>0x7fff) y = 0x7fff;
  if (y<-0x7fff) y = -0x7fff;
*/
  fprintf(outf,"%d,%d,\n",x,y);
}

void PutPathBits(FILE *outf, int pencil = 1)
{
  fprintf(outf,"%d,\n",pencil);
}

void ConvertSVG(char *name)
{
  unsigned int PencilColors[8];
  int PencilsUsed = 0;
  int Pencil=0;
  FILE *in;
  in = fopen(name,"rb");
  fseek(in,0,SEEK_END);
  int len = ftell(in);
  fseek(in,0,SEEK_SET);
  fread(Buffer,1,len,in);
  fclose(in);
  
  FILE *outf;
  outf = fopen("svgart.hpp","w");
  fprintf(outf,"#define blowUpFactorX ((float)MSXRES/(float)SVGXRES)\n");
  fprintf(outf,"#define blowUpFactorY ((float)MSYRES/(float)SVGYRES)\n");
  fprintf(outf,"short PathData[]={\\\n");

  bool Path = false;
  int Refcount = 0;
  int pathNr = 0;
  for (int i = 8; i < len; ++i)
  {
    if (Buffer[i]=='<')
    {
      if ((Buffer[i+1]=='p')&&(Buffer[i+2]=='a')&&(Buffer[i+3]=='t')&&(Buffer[i+4]=='h'))
        Path=true;
      Refcount++;
    }
    if (Buffer[i]=='>')
    {
      Path=false;
      Refcount--;
    }

    // switch pencil onehand of the fill color
    if (Buffer[i]=='#'&&Buffer[i-1]==':'&&Buffer[i-2]=='l'&&Buffer[i-3]=='l'&&Buffer[i-4]=='i'&&Buffer[i-5]=='f'&&Path)
    {
      i++;
      unsigned int color=0;
      for (int k=0;k<8;++k)
      {
        bool dontquit=false;
        if ((Buffer[i]>='0')&&(Buffer[i]<='9'))
        {
          dontquit=true;
          color *= 16;
          color += Buffer[i]-'0';
        }
        if ((Buffer[i]>='A')&&(Buffer[i]<='F'))
        {
          dontquit=true;
          color *= 16;
          color += Buffer[i]-'A'+10;
        }
        if ((Buffer[i]>='a')&&(Buffer[i]<='f'))
        {
          dontquit=true;
          color *= 16;
          color += Buffer[i]-'a'+10;
        }
        if (!dontquit)
          break;
        i++;
      }
      //color |= 0xff000000; // surpress full alpha
      Pencil=-1;
      for (int k = 0; k < PencilsUsed; ++k)
      {
        if (PencilColors[k]==color)
          Pencil=k;
      }
      if (Pencil==-1)
      {
        PencilColors[PencilsUsed]=color;
        Pencil=PencilsUsed;
        PencilsUsed++;
      }
    }
    // we found a path
    if ((Buffer[i]=='M') && (Buffer[i-1]=='"') && (Buffer[i-2]=='=') && Path)
    {
      int startingOne = 1;
      float coord[3];
      int coordindex;
      int afterdot;
      float dotfact;
      while (Buffer[i]!='"' && i < len)
      {
        if (Buffer[i]=='M')
        {
          lastWasC0orL1orM2=2;
          if (!startingOne)
          {
            OutputCoords(outf,coord[0],coord[1]);
            fprintf(outf,"0x4000,\n");
          }
          startingOne = 0;
          PutPathBits(outf,Pencil);
          lastcoordx=0.f;
          lastcoordy=0.f;
          coord[0]=0.f;
          coord[1]=0.f;
          coordindex=0;
          afterdot=0;
          i++;
          while(Buffer[i]==' ') i++;
          continue;
        }
        if (Buffer[i]=='C')
        {
          lastWasC0orL1orM2=0;
          OutputCoords(outf,coord[0],coord[1]);
          coord[0] = 0.f;
          coord[1] = 0.f;
          coordindex = 0;
          afterdot = 0;
          i++;
          while(Buffer[i]==' ') i++;
          continue;
        }
        if (Buffer[i]=='L')
        {
          lastWasC0orL1orM2=1;
          OutputCoords(outf,coord[0],coord[1]);
          coord[0] = 0.f;
          coord[1] = 0.f;
          coordindex = 0;
          afterdot = 0;
          i++;
          while(Buffer[i]==' ') i++;
          continue;
        }
        if (Buffer[i]>='0'&&Buffer[i]<='9')
        {
          if (!afterdot)
          {
            coord[coordindex]*=10.f;
            coord[coordindex]+=Buffer[i]-'0';
          }
          else
          {
            coord[coordindex]+=(Buffer[i]-'0')*dotfact;
            dotfact*=0.1f;
          }
        }
        if (Buffer[i]==',')
        {
          coordindex++;
          if (coordindex>2)
            coordindex = 2;
          afterdot = 0;
        }
        if (Buffer[i]==' ' && (coordindex == 0))
        {
          coordindex++;
          if (coordindex>2)
            coordindex = 2;
          afterdot = 0;
          while(Buffer[i]==' ')++i;
          --i;
        }
        if (Buffer[i]=='.')
        {
          afterdot = 1;
          dotfact = 0.1f;
        }
        ++i;
      }
      OutputCoords(outf,coord[0],coord[1]);
      fprintf(outf,"0x4000,\n"); 
    }
  }
  fprintf(outf,"0x1ace\n");
  fprintf(outf,"};\n");
  fprintf(outf,"unsigned int PencilColors[] = {");
  for (int i=0;i < PencilsUsed; ++i)
    fprintf(outf,"0x%x,",PencilColors[i]);
  fprintf(outf,"};\n");
  fprintf(outf,"#define PENCOUNT %d\n",PencilsUsed);

  fclose(outf);
}

#endif